# Handoff: StreetIQ — Voice Copilot Demo (BMW theme)

## Overview
StreetIQ is a voice-first delivery copilot. This handoff is a **single-screen, 1×4 panel demo** designed to be projected as a hands-free pitch artifact: Driver A's voice cockpit, an adaptive map, the dispatch table, and Driver B's proactive copilot — all visible at once, with a scripted demo button at the top that runs the closed-loop story end-to-end.

## About the Design Files
The files in this bundle are **design references created in HTML/React** — a working prototype that demonstrates the intended look and behavior. They are not production code to copy directly.

The task is to **recreate this design in the StreetIQ codebase's existing environment** (React + Tailwind, per the repo this design references). Use the codebase's established components, routing, state, and styling patterns. Treat the JSX in this bundle as a layout/spec, not a drop-in.

## Fidelity
**High-fidelity (hifi).** Colors, typography, spacing, and panel structure are final. Reproduce pixel-perfectly using the codebase's existing libraries and patterns.

## Theme — BMW only
The handoff is locked to a single theme: a cool silver background with a deep BMW-blue accent, set in Space Grotesk. No tweak panel, no alternate palettes — those existed in the prototype only for exploration.

### Design Tokens

**Background palette (BMW silver)**
- `bg`        `#F2F5F9` — outer panel background (panels 01, 03)
- `bgDeep`    `#F8FAFC` — alternating panel background (panels 02, 04)
- `surface`   `#FAFBFD` — inner cards, system bars
- `surfaceUp` `#FFFFFF` — primary cards (current parcel, alert, map shell)
- `hair`      `#CFD6DF` — borders, dividers
- `hairSoft`  `#DDE2EA` — soft borders

**Ink**
- `ink`       `#1C1B1A` — primary text
- `inkSoft`   `#5A5752` — secondary text
- `inkFaint`  `#8E8B85` — labels, timestamps

**Primary accent — BMW blue (oklch 250)**
- `accent`      `oklch(58% 0.16 250)` — active states, Driver A indicator
- `accentDeep`  `oklch(42% 0.17 250)` — primary CTA, panel rule, "Accept reroute"
- `accentWash`  `oklch(94% 0.03 250)` — accent badge backgrounds

**Functional accents (used sparingly)**
- amber:   `oklch(74% 0.15 75)` / deep `oklch(56% 0.14 75)` / wash `oklch(95% 0.05 75)` — proactive alerts, approaching state
- rust:    `oklch(60% 0.17 30)` / deep `oklch(48% 0.16 30)` / wash `oklch(94% 0.04 30)` — closures, errors
- ink2:    `oklch(50% 0.10 245)` / deep `oklch(38% 0.11 245)` / wash `oklch(94% 0.03 245)` — Driver B / dispatch info

### Typography
- Headlines: **Space Grotesk** 500/600, letter-spacing -0.01em, line-height 1.15–1.4
- Body / UI: **Inter** (system fallback)
- Mono: **JetBrains Mono** for codes (P-001), timestamps, labels (PANEL 01, etc.)
- Sizes: panel title 17px · address 19px · ETA 22px (mono) · system labels 10–11px (mono, +0.14em tracking, uppercase)

### Spacing
- Panel padding: 18px sides, 14–16px vertical
- Card padding: 14–18px
- Card radius: 14px (large), 10px (medium), 6px (small)
- Vertical rhythm: 16px between major blocks
- Hairline borders: 1px solid `hair`

## Screens / Views

### Single screen — 1600 × 900 stage, fit-to-viewport scaled

**Top system bar (44px)**
- StreetIQ wordmark · `VOICE COPILOT · DEMO` mono label
- Driver A state buttons: DRIVING / APPROACHING / PARKED (segmented)
- Driver B state buttons: DRIVING / APPROACHING / PARKED
- Right side: **Reset** (ghost) · **▶ Run Scripted Demo** (primary, accentDeep fill)

**Panel 01 — Voice Cockpit (Driver A)**
- Driver state pill, timestamp
- Current parcel card (P-001, address, customer, ETA)
- Large 88px circular speak button (sage/standby states)
- B-style waveform bars (22 bars, animated when listening/speaking)
- Live transcript + intent chip (e.g. `INTENT: report_closure`)
- 4 quick-test phrase chips at bottom

**Panel 02 — Adaptive Map (Driver A · shared layer)**
- Hidden until needed: shows "Map idle" placeholder by default
- When active: SVG mini-map with streets, route polyline, parking heat-spots
- On road closure: red X marks Maple, amber dashed reroute through Pine
- Heatmap legend (0 / 1-3 / 4-7 / 8+ open spots)
- "shared by 47 colleagues" italic caption

**Panel 03 — Dispatch (6 parcels · 2 drivers)**
- Compact table: ID · STOP · CUSTOMER · DRV · ETA
- Driver chip is colored: A = accent wash, B = ink2 wash
- Status badge per row (PENDING, etc.)
- Bottom system log strip (220px) with `LIVE` pulse dot, monospace event lines

**Panel 04 — Proactive Copilot (Driver B)**
- Driver B state pill
- Current parcel card (P-004)
- **Proactive alert card** (amber border, 4px left rule):
  - "Otto · proactive alert" header
  - Headline (italic): *"A colleague just reported Maple Street is closed. Want me to show an alternate route?"*
  - **Dismiss** (ghost) · **Accept reroute** (accentDeep fill) buttons
- After accept: confirmation + small inline map preview
- Idle state: "Awaiting intelligence" italic placeholder

**Bottom strip (26px)**
- `CLOSED-LOOP DEMO · A SPEAKS → DISPATCH UPDATES → B IS ALERTED` · timestamp

## Interactions & Behavior

### Voice cockpit
- Tap speak button → cycles standby → listening → speaking → standby
- Quick-test chips inject scripted transcripts; each carries an intent
- "Road closed on Maple" intent triggers the closed-loop chain (see below)

### Closed-loop scripted demo
The **▶ Run Scripted Demo** button runs the pitch story:
1. Driver A says "Road closed on Maple" (panel 01: listening → transcript)
2. System log (panel 03) appends `closure reported by A · Maple St`
3. Map (panel 02) reveals with closure X + reroute polyline
4. Driver B alert (panel 04) fires after ~2s
5. Accept → map preview in panel 04 confirms the reroute

### State machine (in `streetiq-panels.jsx`)
- `voiceMode`: `standby | listening | speaking`
- `driverAState`, `driverBState`: `Driving | Approaching | Parked`
- `roadClosed`: boolean — toggles map overlay + reroute
- `transcript`, `intent`: voice cockpit display
- `bAlertVisible`, `bAlertAccepted`: panel 04 alert lifecycle
- `systemLog`: array of `{time, event, driver}`

### Animations
- Waveform bars: opacity + height pulse on `listening`/`speaking`
- Speak button: 8px sage-wash glow ring when active
- LIVE dot: 1.6s ease-in-out pulse
- Map reveal: instant swap (idle ↔ active); polylines render statically
- All transitions: `all .25s` default

## Layout (1×4 horizontal grid)
- Outer stage: 1600 × 900, scaled to viewport via `transform: scale()`
- Stage flex: column → top bar (44) · 4-panel row (flex 1) · bottom strip (26)
- Panel row: 4 equal-width children with `borderRight: 1px solid hair` between
- Each panel: column flex with header (54px) + scrollable body
- Panel header has a 3px-wide accent rule on the left edge (color-coded per panel)

## Files in this bundle
- `StreetIQ.html` — root file with React/Babel CDN + Google Fonts (Space Grotesk, Inter, JetBrains Mono)
- `streetiq-panels.jsx` — full component tree (PanelShell, Panel1–Panel4, top bar, system bar, state reducer, scripted demo). **BMW theme is hard-coded** at module load.
- `tweaks-panel.jsx` — included only because the prototype imports it; **strip this from the production build** — there are no runtime tweaks in the handoff theme.

## Implementation notes
- The prototype renders at fixed 1600×900 and scales to fit. In a production embed, render responsive instead — keep the 1×4 layout above ~1280px wide; collapse to 2×2 below.
- All colors are inline styles. In production, lift them into theme tokens (Tailwind config or CSS custom properties).
- The accent palette uses `oklch()` — supported in all modern browsers; provide hex fallbacks if you need to support older WebViews.
- The map is hand-rolled SVG. If StreetIQ already has a map component (Mapbox/Leaflet), substitute it and recreate the closure marker + reroute polyline as overlays.
- The waveform is purely decorative (static height array). Wire it to real mic levels when integrating with the speech stack.

## Assets
No external images or icons. All imagery is CSS, SVG, or text glyphs (▶, ●). Logos/avatars not included — driver names are placeholder strings.
